var tpl = require("./index.html");
var div = document.createElement("div");
div.id = "iList";
div.style.zIndex = 129999;
div.innerHTML = tpl;
document.body.appendChild(div);