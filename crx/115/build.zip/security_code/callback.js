import Vue from "vue"

new Vue({
  el: "#bmwzz",
  data: {
    message: "X Close!"
  },
  methods: {
    closex() {
      window.close()
    },
    Close911_1514902518714() {
      console.log("callback")
    }
  },
  mounted() {
    // 这里就拿到了iframe的对象
    // console.log(this.$refs.iframe)
    //console.log(this.$refs.iframe.contentWindow)
  }
})

$(document).ready(function () {
  $(document).ajaxComplete(function () {
    console.log("jaxx")
  })
})

